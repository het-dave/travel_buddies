package com.example.travelbuddies

import android.os.Binder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.travelbuddies.databinding.BuddiesListBinding

class buddies_list : AppCompatActivity() {
    lateinit var binding : BuddiesListBinding
    var buddieslist = ArrayList<buddy>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = BuddiesListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        buddieslist=ArrayList<buddy>()
        buddieslist.add(buddy("Rahul","rahul@iitj.ac.in"))
        buddieslist.add(buddy("Manish","manish@iitj.ac.in"))
        buddieslist.add(buddy("Ravish","ravish@iitj.ac.in"))


        binding.recyclerView.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        binding.recyclerView.adapter = BuddyAdapter(this,buddieslist)



    }

}