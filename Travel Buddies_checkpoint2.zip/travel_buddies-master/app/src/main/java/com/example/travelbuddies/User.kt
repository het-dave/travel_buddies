package com.example.travelbuddies

data class User(val name: String? = null,val email : String?=null,val photo : String?=null,val uid : String?=null,val toogle : Boolean=false ){


}
