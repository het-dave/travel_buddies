package com.example.travelbuddies

data class buddy(
    val name: String=" ",
    val email: String=" ",
)
